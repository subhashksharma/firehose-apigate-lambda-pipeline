exports.handler = async (event) => {
    console.log("Received event:", JSON.stringify(event, null, 2));
    
    return {
        statusCode: 200,
        body: JSON.stringify({
            message: "Hello World",
            input: event,
        }),
    };
};

// handler({"key": "value"})
//     .then(response => console.log("Response:", response))
//     .catch(error => console.error("Error:", error));
// This is a simple AWS Lambda function handler that logs the incoming event